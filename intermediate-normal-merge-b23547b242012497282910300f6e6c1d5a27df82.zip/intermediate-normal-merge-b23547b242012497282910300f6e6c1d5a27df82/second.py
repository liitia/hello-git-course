print("Hello from another file")
